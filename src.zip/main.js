import { createApp } from "vue";
import { createPinia } from "pinia";
import App from "./App.vue";
import router from "./router";

// Bootstrap CSS
import "@/assets/css/bootstrap.css";

// Custom CSS
import "@/assets/css/style.css";
import "@/assets/css/css_slider.css";
import "@/assets/css/font-awesome.min.css";

const app = createApp(App);
app.use(createPinia());
app.use(router);
app.mount("#app");
