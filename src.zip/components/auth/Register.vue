<template>
    <section class="contact py-5" id="contact">
        <div class="container py-md-5">
            <h3 class="heading text-center mb-3 mb-sm-5">회원가입</h3>
            <p class="heading text-center mb-3 mb-sm-5">간편한 회원가입으로 방문했던 여행지를 기록하고, 추억을 남겨봐요</p>
            <div class="contact-grids mt-5">
                <div class="row">
                    <div class="col-lg-6 col-md-6 contact-left-form">
                        <form action="#" method="post">
                            <div>아이디</div>
                            <div class="form-group contact-forms">
                                <input type="text" class="form-control" placeholder="id" required="" />
                            </div>
                            <div>비밀번호 *영문자 및 숫자, 특수문자 8자리 이상</div>
                            <div class="form-group contact-forms">
                                <input type="password" class="form-control" placeholder="password" required="" />
                            </div>
                            <div>비밀번호 확인</div>
                            <div class="form-group contact-forms">
                                <input type="password" class="form-control" placeholder="password" required="" />
                            </div>
                            <div>이메일</div>
                            <div class="form-group contact-forms">
                                <input type="email" class="form-control" placeholder="email" required="" />
                            </div>
                            <button class="btn btn-block sent-butnn">회원가입</button>
                        </form>
                    </div>
                    <div class="col-lg-6 col-md-6 contact-right pl-lg-5">
                        <img v-bind:src="imgPath" class="img-fluid" alt="user-image" />
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script setup>
import ImageUrl from '/src/assets/images/c1.jpg';
const imgPath = ImageUrl;
</script>
