<template>
	<section class="gallery py-5" id="gallery">
		<div class="container py-md-5">
			<div class="header mb-3 mb-sm-5 text-center">
				<h3 class="heading text-center mb-3 mb-sm-5">갤러리</h3>
				<p class="heading text-center mb-3 mb-sm-5">우리나라의 아름다운 풍경을 공유하고, 감상해봐요!</p>
				<div class="row news-grids text-center">
					<div class="col-md-4 gal-img">
						<a href=""> <img src="/src/assets/images/gallery/0.jpg" class="img-fluid" /><span>창원 산책로</span></a>
					</div>
					<div class="col-md-4 gal-img">
						<a href=""
							><img src="/src/assets/images/gallery/1.jpg" class="img-fluid" /><span
								>강남 고층 빌딩 강남 고층 빌딩 강남 고층 빌딩 강남 고층 빌딩 강남 고층 빌딩</span
							></a
						>
					</div>
					<div class="col-md-4 gal-img">
						<a href=""><img src="/src/assets/images/gallery/2.jpg" class="img-fluid" /><span>강남 고층 빌딩</span></a>
					</div>
					<div class="col-md-4 gal-img">
						<a href=""><img src="/src/assets/images/gallery/3.jpg" class="img-fluid" /><span>강남 고층 빌딩</span></a>
					</div>
					<div class="col-md-4 gal-img">
						<a href=""><img src="/src/assets/images/gallery/4.jpg" class="img-fluid" /><span>강남 고층 빌딩</span></a>
					</div>
					<div class="col-md-4 gal-img">
						<a href=""><img src="/src/assets/images/gallery/5.jpg" class="img-fluid" /><span>강남 고층 빌딩</span></a>
					</div>
					<div class="col-md-4 gal-img">
						<a href=""> <img src="/src/assets/images/gallery/0.jpg" class="img-fluid" /><span>창원 산책로</span></a>
					</div>
					<div class="col-md-4 gal-img">
						<a href=""><img src="/src/assets/images/gallery/1.jpg" class="img-fluid" /><span>강남 고층 빌딩</span></a>
					</div>
					<div class="col-md-4 gal-img">
						<a href=""><img src="/src/assets/images/gallery/2.jpg" class="img-fluid" /><span>강남 고층 빌딩</span></a>
					</div>
					<div class="col-md-4 gal-img">
						<a href=""><img src="/src/assets/images/gallery/3.jpg" class="img-fluid" /><span>강남 고층 빌딩</span></a>
					</div>
					<div class="col-md-4 gal-img">
						<a href=""><img src="/src/assets/images/gallery/4.jpg" class="img-fluid" /><span>강남 고층 빌딩</span></a>
					</div>
					<div class="col-md-4 gal-img">
						<a href=""><img src="/src/assets/images/gallery/5.jpg" class="img-fluid" /><span>강남 고층 빌딩</span></a>
					</div>
				</div>
			</div>
			<!-- popup-->
			<div id="gal1" class="pop-overlay animate">
				<div class="popup">
					<img src="../images/g1.jpg" alt="Popup Image" class="img-fluid" />
					<p class="mt-4">
						장소: 창원시<br />
						업로드: randomMan003
					</p>
					<a class="close" href="#gallery">&times;</a>
				</div>
			</div>
			<!-- //popup -->

			<!-- popup-->
			<div id="gal2" class="pop-overlay animate">
				<div class="popup">
					<img src="../images/g2.jpg" alt="Popup Image" class="img-fluid" />
					<p class="mt-4">
						장소: 서울특별시 강남구<br />
						업로드: randomMan003
					</p>
					<a class="close" href="#gallery">&times;</a>
				</div>
			</div>
			<!-- //popup -->
			<!-- popup-->
			<div id="gal3" class="pop-overlay animate">
				<div class="popup">
					<img src="../images/g3.jpg" alt="Popup Image" class="img-fluid" />
					<p class="mt-4">
						장소: 합천시<br />
						업로드: randomMan003
					</p>
					<a class="close" href="#gallery">&times;</a>
				</div>
			</div>
			<!-- //popup3 -->
			<!-- popup-->
			<div id="gal4" class="pop-overlay animate">
				<div class="popup">
					<img src="../images/g4.jpg" alt="Popup Image" class="img-fluid" />
					<p class="mt-4">
						장소: 대전 남간정사<br />
						업로드: randomMan003
					</p>
					<a class="close" href="#gallery">&times;</a>
				</div>
			</div>
			<!-- //popup -->
			<!-- popup-->
			<div id="gal5" class="pop-overlay animate">
				<div class="popup">
					<img src="/src/assets/images/gallery/5.jpg" alt="Popup Image" class="img-fluid" />
					<p class="mt-4">
						장소: 서울시 경복궁<br />
						업로드: randomMan003
					</p>
					<a class="close" href="#gallery">&times;</a>
				</div>
			</div>
			<!-- //popup -->
			<!-- popup-->
			<div id="gal6" class="pop-overlay animate">
				<div class="popup">
					<img src="../images/g6.jpg" alt="Popup Image" class="img-fluid" />
					<button class="like_btn">
						<span id="icon"><i class="far fa-thumbs-up"></i></span>
						<span id="count">0</span> Like
					</button>
					<p class="mt-4">
						장소: 서귀포시<br />
						업로드: randomMan003
					</p>
					<a class="close" href="#gallery">&times;</a>
				</div>
			</div>
			<!-- //popup -->
		</div>
	</section>
	<!--// gallery -->
</template>

<style scoped>
.gal-img img {
	width: 100%;
	height: 15rem; /* 원하는 높이로 설정 */
	object-fit: cover;
}
.gal-img span {
	display: block;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
	max-width: 100%;
}
</style>
