<template>
	<div class="col-md-4 gal-img">
		<router-link :to="{ name: 'galleryDetail', params: { id: item.boardId } }" custom v-slot="{ navigate }">
			<a @click="navigate" role="link">
				<img :src="item.imageUrl" class="img-fluid" />
				<span>{{ item.title }}</span>
			</a>
		</router-link>
	</div>
</template>

<script setup>
defineProps({
	item: {
		type: Object,
		required: true,
	},
});
</script>
