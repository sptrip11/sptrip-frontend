<template>
	<!-- footer -->
	<footer class="footer-content py-3">
		<div class="container py-md-3">
			<div class="footer-top text-center">
				<h2>
					<a class="navbar-brand pt-3 mb-3" href="index.html"> <span class="fa fa-free-code-camp"></span> HardPastaTravel </a>
				</h2>
			</div>
			<div class="row footer-top-inner-vv">
				<div class="col-lg-3 col-sm-6 mt-lg-0 mt-4">
					<div class="footer-lavi">
						<h3 class="mb-3 lavi_title">
							<a href="#about"><About class="fa fa-angle-double-right" aria-hidden="true"> 지역별 관광지</About></a>
						</h3>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6 mt-lg-0 mt-4">
					<div class="footer-lavi">
						<h3 class="mb-3 lavi_title">
							<a href="#about"><About class="fa fa-angle-double-right" aria-hidden="true"> 갤러리</About> </a>
						</h3>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6 mt-lg-0 mt-4">
					<div class="footer-lavi">
						<h3 class="mb-3 lavi_title">
							<a href="#about"><About class="fa fa-angle-double-right" aria-hidden="true"> 여행정보공유</About></a>
						</h3>
					</div>
				</div>
			</div>
		</div>
		<!-- //footer bottom -->
	</footer>
	<!-- //footer -->
</template>
