<script setup></script>

<template>
	<div class="st flex-column">
		<h1 style="font-size: 10rem; padding-top: 1em">404</h1>
		<h1 class="st" style="height: 10rem">Page Not Found</h1>
		<p class="text-bg-light blockquote" style="font-size: 2rem">
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sollicitudin justo ac eros maximus semper. Duis id rutrum ligula. Proin sit amet
			pharetra arcu. Duis felis purus, pulvinar in tortor et, condimentum congue eros. Pellentesque non justo sed enim rutrum mollis. Integer id eros
			dignissim, molestie dui vitae, iaculis nibh. Aenean ac vulputate lacus, sit amet scelerisque libero. Maecenas sagittis condimentum odio, id iaculis
			dui pellentesque non. Sed nec tellus id nisl iaculis ultrices quis ac tellus. Cras at ex metus. Vestibulum et pulvinar risus. Fusce viverra euismod
			mi ac convallis. In at tincidunt nisl. Curabitur ut tellus euismod, bibendum lacus ut, faucibus velit. Nulla tristique, eros id mollis efficitur,
			arcu ex interdum massa, eget sollicitudin libero enim at sem. Nulla tincidunt tristique tristique. Praesent nec neque id nulla pretium auctor. In ut
			quam urna. Nulla sed commodo sapien. Fusce ultricies pulvinar suscipit. Duis eu odio magna. Nunc vehicula non nisl a rutrum. Proin gravida luctus
			metus. Aliquam erat volutpat. Mauris faucibus vitae velit vitae imperdiet. In mattis odio sed dolor iaculis, nec pulvinar nulla imperdiet. Sed
			aliquam pulvinar dapibus. Nullam tincidunt, odio non interdum finibus, nibh orci pharetra ante, eu sollicitudin lorem libero nec erat. Mauris eu
			convallis urna, et elementum purus. Suspendisse potenti. Praesent nibh urna, iaculis id bibendum non, molestie in erat. Sed sollicitudin vehicula
			rhoncus. Maecenas id libero ligula. Nunc libero dui, tempus nec odio ut, tincidunt efficitur purus.
		</p>
	</div>
</template>

<style scoped>
.st {
	display: flex;
	justify-content: center;
	align-items: center;
}
</style>
