import { ref } from "vue";
import { defineStore } from "pinia";
import router from "@/router";
import axios from "axios";

const REST_BOARD_API = "http://localhost:8080/api/board";

export const useBoardStore = defineStore("board", () => {
  const boardList = ref([]);
  const board = ref({});
  const getBoardList = () => {
    axios
      .get(REST_BOARD_API)
      .then((res) => {
        boardList.value = res.data;
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const getBoard = (id) => {
    axios
      .get(`${REST_BOARD_API}/${id}`)
      .then((res) => {
        board.value = res.data;
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const writeBoard = (board) => {
    axios.post(REST_BOARD_API, board, { headers: { "Content-Type": `application/json` } }).then((res) => {
      console.log(res);
    });
  };

  const updateBoard = () => {
    axios.patch(REST_BOARD_API, board.value).then(() => {
      router.push({ name: "boardList" });
    });
  };

  const deleteBoard = (id) => {
    axios.delete(`${REST_BOARD_API}/${id}`).then(() => {
      console.log(res);
    });
  };

  return { boardList, board, getBoardList, getBoard, writeBoard, updateBoard, deleteBoard };
});
