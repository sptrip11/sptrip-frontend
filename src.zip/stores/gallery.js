import { ref } from "vue";
import { defineStore } from "pinia";
import axios from "axios";

const REST_GALLERY_API = "http://localhost:8080/board";

export const useGalleryStore = defineStore("gallery", () => {
	const currentPage = ref(1);
	const galleryItems = ref([]);
	const isLoading = ref(false);

	const fetchGalleryItems = async () => {
		isLoading.value = true;
		const response = await axios.get(`${REST_GALLERY_API}/list?page=${currentPage.value}&size=6`);

		// 각 item에 imageUrl 속성을 추가
		const tempGalleryItems = response.data.map((item) => ({
			...item,
			imageUrl: `src/assets/images/gallery/${Math.floor(Math.random() * 27) + 1}.jpg`,
		}));

		//galleryItems.value.push(...response.data);
		currentPage.value++;
		isLoading.value = false;
	};

	const createGalleryItem = async (item) => {
		await axios.post(REST_GALLERY_API, item, { headers: { "Content-Type": "application/json" } });
		fetchGalleryItems(); // 새로운 아이템을 추가한 후 갤러리 아이템 목록을 갱신합니다.
	};

	const updateGalleryItem = async (item) => {
		await axios.put(`${REST_GALLERY_API}/${item.id}`, item, { headers: { "Content-Type": "application/json" } });
		fetchGalleryItems(); // 아이템을 수정한 후 갤러리 아이템 목록을 갱신합니다.
	};

	const deleteGalleryItem = async (id) => {
		await axios.delete(`${REST_GALLERY_API}/${id}`);
		fetchGalleryItems(); // 아이템을 삭제한 후 갤러리 아이템 목록을 갱신합니다.
	};

	return { currentPage, galleryItems, isLoading, tempGalleryItems, fetchGalleryItems, createGalleryItem, updateGalleryItem, deleteGalleryItem };
});
