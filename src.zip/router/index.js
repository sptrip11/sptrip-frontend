import { createRouter, createWebHistory } from "vue-router";
import HomeView from "../views/HomeView.vue";
import GalleryView from "../views/GalleryView.vue";
import GalleryList from "@/components/gallery/GalleryList.vue";
import GalleryDetail from "@/components/gallery/GalleryDetail.vue";
import GalleryWrite from "@/components/gallery/GalleryWrite.vue";
import GalleryUpdate from "@/components/gallery/GalleryUpdate.vue";
import Login from "@/components/auth/Login.vue";
import Register from "@/components/auth/Register.vue";
import NotFound from "@/components/common/NotFound.vue";

const router = createRouter({
	history: createWebHistory(import.meta.env.BASE_URL),
	routes: [
		{
			path: "/",
			name: "home",
			component: HomeView,
		},
		{
			path: "/register",
			name: "register",
			component: Register,
		},
		{
			path: "/login",
			name: "login",
			component: Login,
		},
		{
			path: "/gallery",
			name: "gallery",
			component: GalleryView,
			children: [
				{
					path: "",
					name: "galleryList",
					component: GalleryList,
				},
				{
					path: "write",
					name: "galleryWrite",
					component: GalleryWrite,
				},
				{
					path: ":id",
					name: "galleryDetail",
					component: GalleryDetail,
				},
				{
					path: "update",
					name: "galleryUpdate",
					component: GalleryUpdate,
				},
			],
		},
		{
			path: "/error",
			name: "notFound",
			component: NotFound,
		},
		{
			path: "/:pathMatch(.*)*",
			redirect: "/error",
		},
	],
});

export default router;
