<template>
  <div>
    <div class="text-center">
      <h2 class="my-h2 my-underline">보드입니다</h2>
    </div>
    <RouterView />
  </div>
</template>

<script setup>
import { RouterView } from "vue-router";
</script>

<style scoped>
.my-h2 {
  display: inline-block;
}

.my-underline {
  background: linear-gradient(to top, #54ddff 20%, transparent 30%);
}
</style>
