<template>
	<div>
		<header v-if="isHeaderTransparent">
			<Header />
		</header>
		<div class="container-fluid bg-secondary" v-else>
			<Header />
		</div>
		<router-view></router-view>
	</div>
</template>

<script setup>
import Header from "/src/components/common/Header.vue";
import Footer from "/src/components/common/Footer.vue";
import { ref, computed } from "vue";
import { useRoute, useRouter } from "vue-router";

const route = useRoute();
const router = useRouter();

const isHeaderTransparent = computed(() => route.path === "/");
</script>

<style />
